// pages/api/billing/checkout.js
// ─────────────────────────────────────────────────────────────────
// Creates a Stripe Checkout session for plan upgrades.
// Frontend calls POST /api/billing/checkout with { priceId }
// ─────────────────────────────────────────────────────────────────

import Stripe from "stripe";
import { getAuth } from "@clerk/nextjs/server";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// ── Price IDs from Stripe dashboard ──────────────────────────────
export const PLANS = {
  starter:      { priceId: process.env.STRIPE_PRICE_STARTER,      name: "Starter",      limit: 5  },
  professional: { priceId: process.env.STRIPE_PRICE_PROFESSIONAL, name: "Professional", limit: -1 },
  business:     { priceId: process.env.STRIPE_PRICE_BUSINESS,      name: "Business",     limit: -1 },
};

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });

  const { priceId } = req.body;
  if (!priceId) return res.status(400).json({ error: "priceId required" });

  // Get or create Stripe customer
  const { data: user } = await supabase
    .from("users")
    .select("stripe_customer_id, email, name")
    .eq("id", userId)
    .single();

  let customerId = user?.stripe_customer_id;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user?.email,
      name: user?.name,
      metadata: { clerkUserId: userId },
    });
    customerId = customer.id;
    await supabase.from("users").update({ stripe_customer_id: customerId }).eq("id", userId);
  }

  // Create checkout session
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    payment_method_types: ["card"],
    line_items: [{ price: priceId, quantity: 1 }],
    mode: "subscription",
    success_url: process.env.NEXT_PUBLIC_URL + "/dashboard?upgraded=true",
    cancel_url: process.env.NEXT_PUBLIC_URL + "/pricing",
    metadata: { userId },
    subscription_data: { metadata: { userId } },
  });

  return res.status(200).json({ url: session.url });
}
